# This is a sample Python script.

# Press Ctrl+F5 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.


def print_hi(carol):
    # Use a breakpoint in the code line below to debug your script.
    print(f'Hi, {carol}')  # Press F9 to toggle the breakpoint.


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    print_hi('PyCharm')

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
print("¡Hola! Mi entorno de Python funciona.")
print("Estoy trabajando en PyCharm.")

def saludar(nombre):
    return f"Hola, {nombre}. Bienvenido a Python."


def main():
    nombre = input("Escribe tu nombre: ").strip()

    if nombre:
        print(saludar(nombre))
    else:
        print("Debes escribir tu nombre.")


if __name__ == "__main__":
    main()
